const roomList = [
    {
        id: 1,
        title: "SSAVLON",
        secret: false,
        userNum: 5,
        playing: false,
    },
    {
        id: 2,
        title: "play",
        secret: false,
        userNum: 4,
        playing: false,
    },
    {
        id: 3,
        title: "ssafy",
        secret: true,
        userNum: 4,
        playing: false,
    },
    {
        id: 4,
        title: "god",
        secret: false,
        userNum: 3,
        playing: false,
    },
    {
        id: 5,
        title: "game",
        secret: true,
        userNum: 2,
        playing: false,
    },
    {
        id: 6,
        title: "come",
        secret: true,
        userNum: 1,
        playing: false,
    },
    {
        id: 7,
        title: "here",
        secret: false,
        userNum: 6,
        playing: true,
    },
    {
        id: 8,
        title: "let",
        secret: true,
        userNum: 6,
        playing: true,
    },
];

export default roomList;