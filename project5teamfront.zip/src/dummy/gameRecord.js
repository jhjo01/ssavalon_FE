const dummies = [
  {
    id: "1",
    win: true,
  },
  {
    id: "2",
    win: false,
  },
  {
    id: "3",
    win: false,
  },
  {
    id: "14",
    win: true,
  },
  {
    id: "5",
    win: true,
  },
  {
    id: "6",
    win: false,
  },
  {
    id: "7",
    win: false,
  },
];
export default dummies;
