import Header from "../components/header/Header";
import MypageInfo from "../components/mypage/MypageInfo";
const Mypage = () => {
  return (
    <>
      <Header />
      <MypageInfo />
    </>
  );
};

export default Mypage;
