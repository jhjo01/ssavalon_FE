import Login from "../components/common/login/Login";

const LoginPage = () => {
  return (
    <>
      <div>
        <Login />
      </div>
    </>
  );
};

export default LoginPage;
